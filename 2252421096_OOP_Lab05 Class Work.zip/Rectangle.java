package com.example.oop5;

public class Rectangle implements Shape {
	public int height,weight;

	public Rectangle(int height, int weight) {
		super();
		this.height = height;
		this.weight = weight;
	}
	public double getArea()
	{
		return height*weight;
	}
}

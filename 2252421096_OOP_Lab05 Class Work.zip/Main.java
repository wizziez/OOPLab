package com.example.oop5;

public class Main {
	public static void main(String[] args) {
		Sports obj1=new Sports();
		obj1.play();
		Sports obj2=new Football();
		obj2.play();
		Sports obj3=new Basketball();
		obj3.play();
		Sports obj4=new Rugby();
		obj4.play();		
	}
}

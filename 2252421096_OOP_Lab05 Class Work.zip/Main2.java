package com.example.oop5;

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle obj1=new Rectangle(5, 6);
		System.out.println("Area of Rectangle: "+obj1.getArea());
		Circle obj2=new Circle(6);
		System.out.println("Area of Circle: "+obj2.getArea());
		Triangle obj3=new Triangle(2, 3);
		System.out.println("Area of Triangle: "+obj3.getArea());
	}

}

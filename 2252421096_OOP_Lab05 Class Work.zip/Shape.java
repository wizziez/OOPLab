package com.example.oop5;

public interface Shape {
	public double getArea();
}

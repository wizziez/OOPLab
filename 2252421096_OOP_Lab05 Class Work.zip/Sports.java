package com.example.oop5;

public class Sports {
	void play()
	{
		System.out.println("I am playing");
	}
}


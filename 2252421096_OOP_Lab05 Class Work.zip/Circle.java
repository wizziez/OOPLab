package com.example.oop5;

public class Circle implements Shape{
	public int radius;

	public Circle(int radius) {
		super();
		this.radius = radius;
	}
	public double getArea()
	{
		return 3.14*radius*radius;
	}
}

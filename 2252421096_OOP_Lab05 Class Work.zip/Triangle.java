package com.example.oop5;

public class Triangle implements Shape{
	public int base,height;

	public Triangle(int base, int height) {
		super();
		this.base = base;
		this.height = height;
	}
	public double getArea()
	{
		return 0.5*base*height;
	}
}

package com.example.oop5;

public class Football extends Sports {
	void play()
	{
		System.out.println("I am Playing Football");
	}
}

package com.example.OOP_LAB_04;

public class BankAccount {
	private String accountNumber;
	private double balance;
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public double getBalance() {
		return balance;
	}
	public void setAccountNumber(String n) {
		accountNumber = n;
	}
	public void setBalance(double b) {
		balance = b;
	}

}

package com.example.OOP_LAB_04;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BankAccount b1 = new BankAccount();
		b1.setAccountNumber("AB-1123");
		b1.setBalance(10000.550);
		System.out.println("Account Number: "+b1.getAccountNumber());
		System.out.println("Balance: "+b1.getBalance());
		
		System.out.println("\n\nTask 2:");
		BankAccount2 b2=new BankAccount2("Raiyan Sarwar","1096","20/04/1999");
		b2.showDetails();
		b2.deposit(20000);
		b2.withdraw(10000);
		b2.deposit(5000);
		b2.showDetails();
	}
}
